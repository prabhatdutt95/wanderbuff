import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Destinations } from './packages';

@Injectable({
  providedIn: 'root'
})
export class PackagesService {
  
  constructor(private http: HttpClient) { }
  getPackages(continent): Observable<Destinations[]>{
    return this.http.get<Destinations[]>("http://localhost:3000/package/destinations/"+continent);
  }
  getHotDeals():Observable<Destinations[]>{
    return this.http.get<Destinations[]>("http://localhost:3000/package/hotDeals")
  }
}
