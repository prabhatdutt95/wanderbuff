import { Component, OnInit } from '@angular/core';
import { PackagesService } from 'src/app/packages/packages.service';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { Destinations } from './packages';
import { FormBuilder, Validators, FormControl } from '@angular/forms';


@Component({
  selector: 'app-packages',
  templateUrl: './packages.component.html',
  styleUrls: ['./packages.component.css']
})

export class PackagesComponent implements OnInit {
  errorMessage: string;
  continent:string;
  packages:Destinations[]= new Array<Destinations>()
  showItinerary=false;
  deal:Destinations = new Destinations();
  bookingPage=false; 
  totalCharges:number=null;
  flights:boolean=false;
  packagePage:boolean=false;
  myHotDeals:string;
  index:number;
  checkOutDate= new Date();


  bookForm = this.fb.group({
    noOfPersons:["1",[Validators.required,Validators.min(1),Validators.max(5)]],
    date: ["", [Validators.required,validateDate]], 
    flights:[true]
  }) 

  constructor(private router: Router,private packagesService:PackagesService,private route:ActivatedRoute,private fb: FormBuilder) { 
    this.continent=this.route.snapshot.paramMap.get('continent');
  }
  ngOnInit() {
    window.scrollTo(0, 0)
    if(this.continent){
      this.getPackages();
    }
    else
      this.getHotDeals();
      
  }
  getPackages(){
    console.log(this.continent);
    this.errorMessage = null;
    var mycontinent=this.continent.toLowerCase();
    this.packagesService.getPackages(mycontinent)
      .subscribe(
      data => {
        this.packages = data;
        // this.show = false
        if(this.packages.length==0){
          this.errorMessage="some error"
        }
      }, error =>
        {
          this.errorMessage = error.error.message;
        }
      );
  }
  openBooking(selectedPackage){
    this.index=2;
    this.deal=selectedPackage;
    this.showItinerary=true;
  }
  getitinerary(selectedPackage){
    this.index=0;
    this.deal=selectedPackage;
    this.showItinerary=true;
  }
  loadBookingPage(dealId){
    this.showItinerary=false;
    this.bookingPage=true;
    sessionStorage.setItem('noOfPersons',this.bookForm.value.noOfPersons);
    sessionStorage.setItem('checkInDate',this.bookForm.value.date);
    sessionStorage.setItem('flight',this.bookForm.value.date);
    this.router.navigateByUrl('/book/'+dealId);
  }
  getHotDeals(){  
    this.packagesService.getHotDeals().subscribe(
      data => {
        this.packages = data;
        // this.show = false
        this.errorMessage = null;
    },
      err => {this.errorMessage = err.error.message,
      this.packages = null}
    );
  }
  calculateCharges(){
    this.totalCharges=0;
    var oneDay = 24*60*60*1000;
    var checkInDate=new Date(this.bookForm.value.date);
    var checkOutDate = Math.round(Math.abs((checkInDate.getTime()+(this.deal.noOfNights)*oneDay)));
    this.checkOutDate=new Date(checkOutDate);
    console.log(this.bookForm.value.flights)
    if(this.bookForm.value.flights===true){
      this.totalCharges=(-(-this.bookForm.value.noOfPersons))*this.deal.chargesPerPerson+this.deal.flightCharges;
      console.log("inside flights",this.totalCharges);
    }
    else{
      this.totalCharges=(-(-this.bookForm.value.noOfPersons))*this.deal.chargesPerPerson;
      console.log(this.totalCharges);
    }
    
  }

}
function validateDate(c: FormControl) {
  let today = new Date();
  var val:string=c.value;
  var checkDate = new Date(val)
  return checkDate>today ? null : {
      checkInDateError: {
          message: "Check In date should be after today"
      }
  };

}
