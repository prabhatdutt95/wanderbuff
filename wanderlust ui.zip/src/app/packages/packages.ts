class DayWiseDetails{
    firstDay:string;
    restDaysSightSeeing:Array<string>=[];
    lastDay:string;
}
class Itinerary{
    packageInclusions:Array<string>=[];
    tourHighlights:Array<string>=[];
    tourPace:Array<string>=[];
    dayWiseDetails:DayWiseDetails= new DayWiseDetails()
}
class Details{
    about:string;
    itinerary:Itinerary = new Itinerary();
}
export class Destinations{
    destinationId:string;
    continent:string;
    name:string;
    imageUrl:string;
    details:Details = new Details();
    noOfNights:number;
    chargesPerPerson:number;
    discount:number;
    availability:number;
    flightCharges:number;
}