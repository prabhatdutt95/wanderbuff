import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Routes, Router } from '@angular/router';

import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from '../app.module';

import {InputTextModule} from 'primeng/inputtext';
import {ButtonModule} from 'primeng/button';
import { RegisterService } from './register.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  errorMessage: string;
  successMessage: string;
  registerForm: FormGroup;

  constructor(private fb: FormBuilder, private registerService: RegisterService, private router: Router) { }

  ngOnInit() {
    this.registerForm = this.fb.group({
      name :  ['', [Validators.required,Validators.pattern('^[a-zA-Z]+$')]],
      emailId: ['', [Validators.email, Validators.required]],
      contactNo: ['', [ Validators.required,Validators.pattern('^[6,7,8,9]{1}[0-9]{9}$')]],
      password: ['', [Validators.required]]
      })
  }
  register(){
    this.registerService.login(this.registerForm.value).subscribe(
      (response) => {
        this.successMessage = response.message;
      },
      (errorResponse) => {
        this.errorMessage = errorResponse.error.message;
      }
    );
   }

}

