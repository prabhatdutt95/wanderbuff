import { Component, OnInit } from '@angular/core';
import { BookService } from './book.service'
import { ActivatedRoute } from '@angular/router';
import { Book } from 'src/app/book/book';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { Destinations } from '../packages/packages';
import { FormBuilder, Validators, FormControl } from '@angular/forms';




@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css'],
  providers:[BookService]
})
export class BookComponent implements OnInit {

  errorMessage: string;
  successMessage: string;
  dialogBox:Boolean = false
  dealId:string
  userId=sessionStorage.getItem('userId');
  destinationDetails:Destinations=new Destinations();
  bookDetails:Book= new Book();
  noOfpersons=sessionStorage.getItem('noOfPersons');
  checkInDate=sessionStorage.getItem('checkInDate');
  flights=sessionStorage.getItem('flights')
  bookingDetails={};
  checkOutDate= new Date();
  totalCharges:number=0;
  showDate=false;
  successBox:boolean=false;
  show:boolean;
  removePage:boolean = true;
  
  constructor(private location: Location,private router: Router, private bookService:BookService,private route:ActivatedRoute,private fb: FormBuilder) { 
    this.dealId=this.route.snapshot.paramMap.get('dealId')
  }
  bookForm = this.fb.group({
    noOfPersons:[this.noOfpersons],
    checkInDate: [this.checkInDate], 
    flights:[this.flights]
  })

  ngOnInit() {
    window.scrollTo(0, 0)
    console.log(sessionStorage.getItem('userId'))
    this.showDate=false;
    this.confirmDetails();
    this.bookingDetails={checkInDate:new Date(this.checkInDate),noOfPersons:Number(this.noOfpersons)}    
  }

  book(){
    this.successMessage=null;
    this.errorMessage=null;
    this.removePage = false;
    this.show=true;
    var checkIndate=this.bookForm.value.checkInDate
    this.bookForm.value.checkInDate= new Date(checkIndate)
    this.bookService.book(this.bookForm.value,this.dealId,this.userId)
    .subscribe(
      response =>{
        this.confirmDetails();
        this.show = false
        this.successMessage = response.message; 
        this.successBox=true;
        sessionStorage.removeItem('checkInDate');
        sessionStorage.removeItem('noOfPersons');
    },
      err => 
        this.errorMessage =  err.error.message);
  }

  confirmDetails(){
    console.log("inside confirm details")
    this.bookService.confirm(this.dealId).subscribe(
      response => {
        console.log(response);
        this.destinationDetails=response;
        this.errorMessage=null;
      },
      err =>{
        console.log(err)
        this.errorMessage = err.error.message;
        this.destinationDetails=null;
      }
    )

    setTimeout(()=>{
      var oneDay = 24*60*60*1000;
      if(this.checkInDate!==""){
        var firstDate = new Date(this.checkInDate); 
        var noOfPeople=Number(this.noOfpersons);
      }
      else{
        var firstDate= new Date(this.bookForm.value.checkInDate);
        var noOfPeople=Number(this.bookForm.value.noOfPersons);
      }
      if(firstDate){
        var secondDate = Math.round(Math.abs((firstDate.getTime()+(this.destinationDetails.noOfNights)*oneDay)));
        this.checkOutDate = new Date(secondDate);
      }
      else{
        this.checkOutDate=new Date();
      }
      if(noOfPeople){
        this.totalCharges = (-(-noOfPeople))*this.destinationDetails.chargesPerPerson;
      }
      else{
        this.totalCharges=this.destinationDetails.chargesPerPerson;
      }
      var includeFlights=this.bookForm.value.flights;
      if(includeFlights){
        this.totalCharges=this.totalCharges+this.destinationDetails.flightCharges;
      }
      var date = Date.parse(this.checkOutDate.toDateString());
      if (!date) {
        console.log(this.checkOutDate)
          this.showDate=false;
      }
      else{
        this.showDate=true;
      }
      
    },2000)
    
  }
   
  goBack(){
    this.location.back();
  }

}
function validateDate(c: FormControl) {
  let today = new Date();
  var val:string=c.value;
  var checkDate = new Date(val)
  return checkDate>today ? null : {
      checkInDateError: {
          message: "Check In checkInDate should be after today"
      }
  };

}


