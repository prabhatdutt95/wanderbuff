export class Book{
    bookingId:string;
    userId: string;
    destId: string;
    checkInDate: Date;
    checkOutDate : Date;
    noOfPersons:number;
    totalCharges:number;
    timeStamp:string;
    message:string;
}