import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Observable} from 'rxjs';
import { Book } from './book';

@Injectable()
export class BookService {
  errorMessage: String;
  url = "http://localhost:3000/book/";
  confirmUrl="http://localhost:3000/book/getDetails";
  deleteUrl="http://localhost:3000/book/cancelBooking";
  

  constructor(private http: HttpClient) { }
  book(data:any,destinationId:string,userId:string) : Observable<Book> {
    console.log("inside book service: ",this.url+userId+"/"+destinationId)
    return <Observable<Book>> this.http.post(this.url+userId+"/"+destinationId,data);
  }
  
  confirm(destinationId:string):Observable<any>{
    console.log("In service",this.confirmUrl+"/"+destinationId)
    return <Observable<any>> this.http.get(this.confirmUrl+"/"+destinationId);
  }

  cancelBooking(bookingID:string):Observable<any>{
    console.log("inside cancel service: ",bookingID)
    return <Observable<any>> this.http.delete(this.deleteUrl+"/"+bookingID)
  }
}
