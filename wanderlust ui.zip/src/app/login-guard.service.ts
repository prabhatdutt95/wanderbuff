import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';


@Injectable()
export class LoginGuard implements CanActivate {

    constructor(private router: Router ) {};
    canActivate():boolean {
        if(this.checkUser()) {
            return true;
        } 
        else {
            this.router.navigate(['/login']);
            alert('Please Login to continue!')
        }
    }

    checkUser():boolean {
        if(sessionStorage.getItem("userId")) {
            return true;
        }
        else return false;
    }
}