//form and http modules
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

//ng prime and other styling modules
import {AccordionModule} from 'primeng/accordion'; 
import {MenuItem} from 'primeng/api';
import {DialogModule} from 'primeng/dialog';
import {SidebarModule} from 'primeng/sidebar';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {TabViewModule} from 'primeng/tabview';
import {InputSwitchModule} from 'primeng/inputswitch';
import {FieldsetModule} from 'primeng/fieldset';
import {ToastModule} from 'primeng/toast';
import {ProgressSpinnerModule} from 'primeng/progressspinner';
import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';


//the components modules
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { PackagesComponent } from './packages/packages.component';
import { BookComponent } from './book/book.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ViewBookingsComponent } from './view-bookings/view-bookings.component';

//services
import { LoginService } from './login/login.service';
import { RegisterService } from './register/register.service';
import { PackagesService } from 'src/app/packages/packages.service';
import { BookService } from './book/book.service';
import { ViewBookingService } from 'src/app/view-bookings/view-booking.service';

//login gaurd and routing
import { LoginGuard } from './login-guard.service';
import { AppRoutingModule } from './app-routing.module';




@NgModule({
  declarations: [
    AppComponent,
    PackagesComponent,
    BookComponent,
    LoginComponent,
    RegisterComponent,
    ViewBookingsComponent,
    HomeComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    AccordionModule,  
    ReactiveFormsModule,
    FormsModule,
    BrowserAnimationsModule,
    DialogModule,
    SidebarModule,
    TabViewModule,
    InputSwitchModule,
    FieldsetModule,
    ToastModule,
    ProgressSpinnerModule,
    Ng4LoadingSpinnerModule.forRoot()
  ],
  providers: [LoginGuard,ViewBookingService,PackagesService,LoginService, RegisterService,BookService],
  bootstrap: [AppComponent]
})
export class AppModule { }
