export class Bookings{
    bookingId:string;
    destId:string;
    destinationName:string;
    checkInDate:string;
    checkOutDate:string;
    noOfPersons:number;
    totalCharges:number;
}