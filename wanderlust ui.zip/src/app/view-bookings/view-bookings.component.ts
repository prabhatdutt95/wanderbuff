import { Component, OnInit } from '@angular/core';
import { ViewBookingService } from 'src/app/view-bookings/view-booking.service';
import { BookService } from '../book/book.service'
import { Bookings } from 'src/app/view-bookings/ViewBooking';
import {Message} from 'primeng/components/common/api';
import {MessageService} from 'primeng/components/common/messageservice';

@Component({
  selector: 'app-view-bookings',
  templateUrl: './view-bookings.component.html',
  styleUrls: ['./view-bookings.component.css'],
  providers: [MessageService]
})
export class ViewBookingsComponent implements OnInit {
  errorMessage=null;
  bookingDetails:Bookings[]=new Array<Bookings>()
  cancellationDetails:Bookings =new Bookings();
  successMessage:string;
  userId=sessionStorage.getItem('userId');
  cancelConfirmation:boolean=false;
  deleted=false;
  show:boolean = true;
  constructor(private viewBookingService:ViewBookingService,private bookService:BookService,private messageService: MessageService) { }

  ngOnInit() {
    this.bookingDetails=[];
    this.errorMessage=null;
    this.getMyBookings1();
  }
  getMyBookings1(){ 
    this.viewBookingService.getMyBookings(this.userId).subscribe(
    data => {
      this.show = false
      this.errorMessage = null;
      for(let i=data.length-1;i>=0;i--){
        this.bookingDetails.push(data[i]);
      }
      console.log(this.bookingDetails)
    },
    err => {
      this.show = false
      console.log(err.error.message);
      this.errorMessage = err.error.message,
      this.bookingDetails = null
    }
    );
  }
  confrimCancellation(booking){
    console.log(booking)
    this.cancelConfirmation=true;
    this.cancellationDetails=booking;
  }
  cancelBooking(bookingId){
    console.log(bookingId);
    this.bookService.cancelBooking(bookingId)
    .subscribe(
      response => {
        this.successMessage=response.message;
        this.showInfo();
        this.ngOnInit();
        this.cancelConfirmation=false;
      },
      error=>this.errorMessage=error.error.message
    )
  }
  showInfo() {
    this.deleted=true;
    this.messageService.add({severity:'info', summary: this.successMessage, detail:''});
  }

}
