import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Bookings } from './ViewBooking';

@Injectable({
  providedIn: 'root'
})
export class ViewBookingService {

  constructor(private http: HttpClient) { }

  getMyBookings(userId:string):Observable<Bookings[]>{
    console.log(userId)
    return this.http.get<Bookings[]>("http://localhost:3000/user/getBookings/"+userId)
  }
}
