import { TestBed } from '@angular/core/testing';

import { ViewBookingService } from './view-booking.service';

describe('ViewBookingService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ViewBookingService = TestBed.get(ViewBookingService);
    expect(service).toBeTruthy();
  });
});
