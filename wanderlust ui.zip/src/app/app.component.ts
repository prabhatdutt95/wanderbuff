import { Component } from '@angular/core';
import { Routes, Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Wanderlust'; 
  userLoggedIn=sessionStorage.getItem('userId');
  userName=sessionStorage.getItem('userName');
  logoutBox=false;
  constructor( private router: Router){}
  ngOnInit(){
    window.scrollTo(0, 0)
    console.log(this.userLoggedIn,this.userName);
  }
  logout(){
    this.logoutBox=false;
    sessionStorage.clear();
    window.location.reload();
    this.router.navigateByUrl('/home');
  }
  confirm(){
    this.logoutBox=true;
  }
}
