export class User {
    userId:string;
    name:string;
    emailId:string;
    contactNo:string;
    password:string;
    message:string;
}
