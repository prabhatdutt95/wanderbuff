//Route 1: /login -> get with routing parameters -> :id and :password
//Route 2: /register ->post
//route 3:/book ->post
//route 4:/viewBookings ->get with parameter

var express = require('express');
var router = express.Router();

var user = require('../public/javascripts/Users/users');
var userBL = require('../public/javascripts/Users/usersBL')

// router to register
router.post('/register', function (req, res, next) {
    var newUser = user.toObject(req.body);
    console.log(newUser)
    userBL.register(newUser).then(function (userid) {
        res.json({ "message": "Successfully Registered! Please login" })
    }).catch(function (error) {
     next(error);
      })
})


router.post('/login', function (req, res, next) {
    var contactNo = req.body.contactNo;
    var password = req.body.password;
    userBL.login(parseInt(contactNo),password).then(function (userDetails) {
      res.json(userDetails);
   }).catch(function (err) {
      next(err);
    })
})

router.get('/getBookings/:userId', function (req,res,next){
    var userId=req.params.userId;
    userBL.getBookings(userId).then(function(bookings){
        res.json(bookings)
    }).catch(function (err) {
        next(err);
    })
})




module.exports = router;

