var express = require('express');
var router = express.Router();
var packageBL = require('../public/javascripts/Packages/packagesBL')

//Route1: /hotDeals -> get
router.get('/hotDeals', function(request,response,next) {
    return packageBL.getHotDeals().then(function(hotdeals){
        response.json(hotdeals)
    }).catch(function(err){
        next(err)
      });
});


//Route 2 : /destinations -> get
router.get('/destinations/:keyword', function(request,response,next) {
    keyword=request.params.keyword;
    return packageBL.getDestinations(keyword).then((destinations) =>
    {     
        response.json(destinations)
    }).catch(function(err){
        next(err)
      });
});

module.exports = router