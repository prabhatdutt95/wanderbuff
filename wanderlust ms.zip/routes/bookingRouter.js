var express = require('express');
var router = express.Router();
var booking = require('../public/javascripts/Bookings/booking')
var bookingBL = require('../public/javascripts/Bookings/bookingsBL')

router.post('/:userId/:destinationId',function(request,response,next){
    var bookingDetails = booking.toObject(request.body)
    var userId = request.params.userId
    var destId = request.params.destinationId
    bookingBL.book(bookingDetails,userId,destId).then(function(bookDetails) {
        response.json({"message":"Booking successfull with Booking Id: "+bookDetails.bookingId})
    }).catch(function(error){
        next(error)
    })
});

router.delete('/cancelBooking/:bookingId',function(request,response,next){
    var bookingId = request.params.bookingId
    bookingBL.delete(bookingId).then(function(result){
        if(result){
            response.json({"message":"Successfully deleted the booking with Id "+bookingId})
        }
    }).catch(function(error){
        next(error)
    }) 
})

router.get('/getDetails/:destinationId',function(request,response,next){
    var  destId = request.params.destinationId
    return bookingBL.getDetails(destId).then(function(details){
        response.send(details)
    }).catch(function(error){
        next(error)
    })

})

module.exports = router