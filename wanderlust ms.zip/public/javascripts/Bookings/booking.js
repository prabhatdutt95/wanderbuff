var bookings = function (bookingId, userId, destId, checkInDate, checkOutDate,noOfPersons,flightCharges,totalCharges,timeStamp){
    this.bookingId = bookingId;
    this.userId = userId;
    this.destId = destId;
    this.checkInDate = checkInDate;
    this.checkOutDate = checkOutDate;
    this.noOfPersons = noOfPersons;
    this.flightCharges = flightCharges;
    this.totalCharges = totalCharges;
    this.timeStamp = timeStamp;
}

bookings.toObject = function(result){
    return new bookings(result.bookingId, result.userId, result.destId, result.checkInDate, result.checkOutDate,result.noOfPersons,result.flightCharges,result.totalCharges,result.timeStamp);
}

module.exports = bookings;