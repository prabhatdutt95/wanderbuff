var bookingDAL = require('./bookingsDAL');
var bookValidator = require("./bookValidator")

var bookingBL = {}

bookingBL.updateCheckoutDate = function(checkInDate,noOfNights) {
    var oneDay = 24*60*60*1000;
    var firstDate = new Date(checkInDate); 
    var secondDate = Math.round(Math.abs((firstDate.getTime()+(noOfNights)*oneDay)))
    var checkOutDate = new Date(secondDate).toLocaleDateString()
    return checkOutDate
}

bookingBL.confirmBook = function(bookingDetails,destinationId){
    return bookingDAL.getDeals(destinationId).then(function(result){
        if(result!=null){
            bookValidator.validateAvailability(result.availability,bookingDetails.noOfPersons)
            bookingDetails.destinationName = result.name
            bookingDetails.timeStamp = new Date().getTime().toString();
            // console.log("Flight charges",bookingDetails.flightCharges)
            if(bookingDetails.flightCharges===true){
                bookingDetails.totalCharges = (bookingDetails.noOfPersons*result.chargesPerPerson)+result.flightCharges  
                // console.log("In confirm charges true",bookingDetails.totalCharges)
            }else{
                bookingDetails.totalCharges = (bookingDetails.noOfPersons*result.chargesPerPerson)
            }
            if(result.discount!=0){
                bookingDetails.totalCharges = (1-(result.discount/100))*bookingDetails.totalCharges
            }
            // console.log("In confirm charges",bookingDetails.totalCharges)
            bookingDetails.checkOutDate = bookingBL.updateCheckoutDate(bookingDetails.checkInDate,result.noOfNights)
            //console.log("Confirm book",bookingDetails)
            return bookingDetails
        } else {
            throw new Error("Enter a Valid Destination Id")
        }
        
    })
}


bookingBL.book = function(bookingDetails,userId,destinationId){

    return bookingBL.confirmBook(bookingDetails,destinationId).then(function(resultBookingDetails){
        if(resultBookingDetails!=null){
            return bookingDAL.getDeals(destinationId).then(function(destDetails){
                if(destDetails){
                    availability = destDetails.availability-bookingDetails.noOfPersons
                    return bookingDAL.book(bookingDetails,userId,destinationId).then(function(bookResult){
                        if(bookResult){
                            return bookingDAL.updateUsers(userId,bookResult.bookingId).then(function(result1){
                                if(result1.result.nModified>=1){
                                    return bookingDAL.updateAvailability(destinationId,availability).then(function(updatedResult){
                                        if(updatedResult){
                                            return bookResult
                                        } else {
                                            throw new Error("Error in updating availability")
                                        } 
                                    })
                                } else {
                                    throw new Error("Error in updating Users")
                                }
                            })
                        } else {
                            throw new Error("Error in BL Booking")
                        }
                    })
                } else {
                    throw new Error("No destination found")
                }
            })
        }
     
    });
}

bookingBL.getDetails = function(destinationId){
    return bookingDAL.getDeals(destinationId).then(function(result){
        if(result){
            return result
        }else {
            throw new Error("Could not get deals")
        }
    })
}


bookingBL.delete = function(bookingId){
    return bookingDAL.delete(bookingId).then(function(result){
        if(result){ 
            return true
        }else{
            throw new Error("Error in deleting Booking details")
        }
    })
}


module.exports = bookingBL