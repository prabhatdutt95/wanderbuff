var oneDay = 24*60*60*1000; // hours*minutes*seconds*milliseconds
var firstDate = new Date("2018-12-08");
var secondDate = new Date("2018-12-16");
var diffDays = Math.round(Math.abs((firstDate.getTime() - secondDate.getTime())/(oneDay)));
console.log(diffDays)
if(diffDays==7){
    console.log("Yes")
}else{
    checkOutDate = Math.round(Math.abs((firstDate.getTime()+7*oneDay)))
    checkOutDate = new Date(checkOutDate)
    console.log("The check out date for this destination should be: "+checkOutDate.getDate()+"-"+checkOutDate.getMonth()+"-"+checkOutDate.getFullYear());
    
    console.log(checkOutDate.toLocaleString())
}