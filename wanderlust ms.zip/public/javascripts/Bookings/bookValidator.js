var bookValidator = {}

bookValidator.validateCheckIn = function(checkInDate){

    var today = new Date()
    var checkInDate = new Date(checkInDate)
    if(checkInDate<today){
        throw new Error("Check In Date should be later than today")
    }
}

bookValidator.validateAvailability = function(availability,noOfPersons) {
    if(availability<=0 || noOfPersons>availability){
        throw new Error("Required number of Seats are not available")
    }
}

module.exports = bookValidator