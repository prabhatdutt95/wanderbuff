var connection = require("../Connections");


var bookingDAL = {}

bookingDAL.generateId = function () {
    return connection.getConnection().then(function (db) {
        var bookingCollection = db.collection('Bookings');
        return bookingCollection.distinct("bookingId").then(function (ids) {
            var bId = Number(ids[ids.length-1].substring(1))
            return "B"+(bId + 1);
        })
    })
}

bookingDAL.getDeals = function(destinationId) {
    return connection.getConnection().then(function(db){
        var destinationCollection = db.collection('Destinations');
        var hotDestinationCollection = db.collection('Hotdeals');
        if(destinationId.substring(0,1)=="D"){
            return destinationCollection.findOne({"destinationId":destinationId}).then(function(foundResult){
                if (foundResult) {
                    return foundResult
                } else {
                    throw new Error("Error in getting Deals")
                }  
            }) 
        } else if(destinationId.substring(0,2)=="HD"){
            return hotDestinationCollection.findOne({"destinationId":destinationId}).then(function(foundResult){
                if(foundResult){
                    return foundResult
                } else {
                    throw new Error("Error in getting Hot Deals")
                }
            })

        }

    })
    
}


bookingDAL.updateAvailability = function(destinationId,availablity) {
    return connection.getConnection().then(function(db){
        var destinationCollection = db.collection('Destinations');
        var hotDestinationCollection = db.collection('Hotdeals')
        if(destinationId.substring(0,1)=="D"){
            //console.log(destinationId)
            return destinationCollection.update({"destinationId":destinationId},{$set: {"availability" :availablity}}).then(function(result){
                if(result.result.nModified == 1){
                    return result
                } else {
                    throw new Error("Error in updating Deals")
                }
            })
        }else if(destinationId.substring(0,2)=="HD"){
            //console.log(destinationId)
            return hotDestinationCollection.update({"destinationId":destinationId},{$set: {"availability" :availablity}}).then(function(result){
                if(result.result.nModified == 1){
                    return true
                } else {
                    throw new Error("Error in updating Hot Deals")
                }
            })
        }
    })
}

bookingDAL.updateUsers = function(userId,bookingId){
    return connection.getConnection().then(function(db){
        var userCollection = db.collection('Users');
        return userCollection.update({"userId":userId},{$push:{"bookings":{$each: [ bookingId ]}}}).then(function(result){
            if(result.result.nModified>=1){
                return result
            } else {
                throw new Error("Error in updating booking Id in users")
            }
            
        })
    })
}

bookingDAL.findUser = function(userId,destinationId){
    return connection.getConnection().then(function(db) {
        var bookingCollection = db.collection('Bookings');
        return bookingCollection.findMany({"userId":userId}).toArray().then(function(foundData){
        })
    })
}

bookingDAL.book = function (bookingDetails,userId,destinationId){
    return connection.getConnection().then(function(db) {
        var bookingCollection = db.collection('Bookings');
        return bookingDAL.generateId().then(function (bookingId) {
            bookingDetails.bookingId = bookingId;
            return bookingCollection.insert({ "bookingId": bookingDetails.bookingId, "userId": userId, "destId": destinationId,"destinationName":bookingDetails.destinationName, "checkInDate": bookingDetails.checkInDate, "checkOutDate": bookingDetails.checkOutDate, "noOfPersons": bookingDetails.noOfPersons, "totalCharges": bookingDetails.totalCharges,"timeStamp": bookingDetails.timeStamp})
            }).then(function (added) {
                if (added.insertedCount < 1)
                    throw new Error('Error occured. Data could not be saved');
                else {
                    return added.ops[0]
                }
            }) 
    });
}
//Deletes a particular booking document from the Bookings Collection
bookingDAL.delete = function(bookingId){
    return connection.getConnection().then(function(db) {
        var bookingCollection = db.collection('Bookings');
        var userCollection = db.collection('Users');
        return bookingCollection.findOne({bookingId:bookingId}).then(function(found){
            if(found){
                var userId = found.userId
                var destId = found.destId
                return bookingDAL.getDeals(destId).then(function(result){
                    if(result){
                        noOfPersons = found.noOfPersons
                        availability = result.availability+noOfPersons
                        return bookingDAL.updateAvailability(destId,availability).then(function(updatedResult){
                            if(updatedResult){
                                return bookingCollection.deleteOne({"bookingId":bookingId}).then(function(deletedResult){
                                    if(deletedResult.deletedCount>=1){
                                        return userCollection.findOne({"userId":userId}).then(function(userFound){
                                            if(userFound){
                                                return userCollection.update({"userId":userId},{$pull:{"bookings":bookingId}}).then(function(updatedResult){
                                                    if(updatedResult.result.nModified>=1){
                                                        return true
                                                    }else{
                                                        throw new Error("Could not delete the bookings from the user")
                                                    }
                                                })
                                            }else{
                                                throw new Error("User not found")
                                            }
                                        })
                                    } else {
                                        throw new Error("Booking data could not be deleted")
                                    }
                                })
                            } else{
                                throw new Error("Could not update availabilility")
                            } 
                        })
                    }
                })
        
            }
        })
    })
    
}

module.exports = bookingDAL