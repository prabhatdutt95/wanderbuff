var userDAL = require('./usersDAL');
var userValidator = require('./userValidator');
var bookingDetail= require('./BookingDetails');


var userBL = {}


userBL.register = function (User) {
	userValidator.validateContact(User.contactNo);
    return userDAL.checkUser(User.contactNo).then(function (userDetails) {
        if (userDetails != null) {
            throw new Error("You have already registered, Please login!");
        } else {
             return  userDAL.register(User);
        }
    }).then(function (accountNo) {
        return accountNo;
    })
}


userBL.login = function (contactNo,userPassword) {
    return userDAL.checkUser(contactNo).then(function (user) {
       if(user==null){
           throw new Error("Enter registered contact number! If not registered, please register")
       }
       else{
           return userDAL.getPassword(contactNo).then(function(password){
               if(password!=userPassword){
                    throw new Error("Incorrect password")
               }
               else{
                   return user;
               }
           })
       }
    })
}
   

userBL.getBookings = function(userId){
    return userDAL.getBookingsArray(userId).then(function(bookingsArray){
        if(bookingsArray.length==0){
            throw new Error("Sorry you have no trips planned with us")
        }
        else{
            return bookingsArray;
        }
    })
}
userBL.getMyBookings = function(bookingsArray){
    fetchedBookings=[];
    for(let i=0;i<bookingsArray.length;i++){
        return userDAL.getBooking(bookingsArray[i]).then(function(booking){
            if(booking!=null){
                fetchedBookings.push(booking);

            }
        })
    }
}


module.exports = userBL
