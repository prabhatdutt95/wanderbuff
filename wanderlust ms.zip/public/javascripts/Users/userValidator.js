
var userValidator = {}

userValidator.validateContact = function(contactNo){
    contact = String(contactNo)
    var regex = new RegExp("^[6,7,8,9]{1}[0-9]{9}$");
    if(!regex.test(contact)){
        throw new Error("Invalid! Please enter a correct Contact Number.");
    }
}

module.exports = userValidator;