var BookingDetails= function(destinationName,checkInDate,checkOutDate,noOfPersons,totalCharges,details){
    this.destinationName=destinationName;
    this.checkInDate=checkInDate;
    this.checkOutDate=checkOutDate;
    this.noOfPersons=noOfPersons;
    this.totalCharges=totalCharges;
    this.details=details;
}

BookingDetails.toObject = function(destinationName,checkInDate,checkOutDate,noOfPersons,totalCharges,details){
    return new BookingDetails(destinationName,checkInDate,checkOutDate,noOfPersons,totalCharges,details)
}

module.exports=BookingDetails;