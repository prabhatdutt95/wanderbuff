var userDetails = require('./users');
var connection = require("../Connections")

var userDAL = {}

userDAL.generateId = function () {
    return connection.getConnection().then(function (db) {
        var userCollection = db.collection('Users');
        return userCollection.distinct("userId").then(function (ids) {
            var bId = Number(ids[ids.length-1].substring(1))
            return "U"+(bId + 1);
        })
    })
}

//insert new customer details
userDAL.register = function (userDetails) {
    return connection.getConnection().then(function (database) {
        return userDAL.generateId ().then(function (userId) {
            userDetails.userId = userId;
            userDetails.bookings=[];
            console.log(userDetails);
            return database.collection('Users').insert(userDetails).then(function (inserted) { 
                if (inserted.insertedCount == 1) {
                      return userDetails.userId
                } else {
                    throw new Error("Failed to register. Please try again!");
                }
        })
    })
})
}

userDAL.checkUser = function (contactNo) {
    return connection.getConnection().then(function (database) {
        return database.collection('Users').findOne({ "contactNo": contactNo }).then(function (customerContact) {
            if (customerContact) 
                {
                return userDetails.toObject(customerContact);}
            else return null;
        })
    })
}

userDAL.getPassword = function (contactNo) {
  return connection.getConnection().then(function(database){
    return database.collection('Users').find({"contactNo": contactNo }).project({_id:0,password:1}).toArray().then(function (password) {
        if (password.length !=0) 
            return password[0].password;
        else 
            return null;
    })
})

}

userDAL.getBookingsArray= function(userId){
    return connection.getConnection().then(function(database){
        return database.collection('Bookings').find({"userId":userId}).toArray().then(function(bookingsArray){
            if(bookingsArray==[])
                return null;
            else   
                return bookingsArray;
        })
    })
}

userDAL.getBooking = function(bookingId){
    return connection.getConnection().then(function(database){
        return database.collection('Bookings').findOne({"bookingId":bookingId}).then(function(booking){
            if(booking!=null)
                return booking;
            else    
                return null;
        })
    })
}

userDAL.getDestination = function(destinationId){
    return connection.getConnection().then(function(database){
        return database.collection('Destinations').findOne({"destinationId":destinationId}).then(function(destination){
            if(destination!=null)
                return destination;
            else    
                return null;
        })
    })
}

module.exports = userDAL
