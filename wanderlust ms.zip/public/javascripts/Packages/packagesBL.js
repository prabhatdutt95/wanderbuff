var packageDAL = require('./packagesDAL')

var packageBL = {}

//this fuction calls getHotDeals function in packagesDAL and returns all hotdeal 
packageBL.getHotDeals = function(){
    return packageDAL.getHotDeals().then((hotdeals) => {
        return hotdeals
    })
}


//this fuction calls getDestinations function in packagesDAL and returns all destinations
packageBL.getDestinations = function(keyword) {
    if(keyword=="europe"||keyword=="asia"||keyword=="australia")
    {
        continentName=keyword[0].toUpperCase()+keyword.substring(1);
        console.log(continentName);
        //if the user has entered a continent name then fetch collection based on continent name
        return packageDAL.getDestinations(continentName).then((destination) =>
        {
            return destination
        })
    }
    else{
        //if the user has entered a place name try to find the name in the tourhighlights attribute of the packages
        return packageDAL.getDestinationstwo().then((destinations)=>{
            packagesArray=[];
            for(packages in destinations){
                tourHighlights=destinations[packages].details.itinerary.tourHighlights;
                for(let highlight in tourHighlights){
                    if(keyword.toLowerCase()==tourHighlights[highlight].toLowerCase()){
                        packagesArray.push(destinations[packages]);
                    }
                }
            }
            return packagesArray;
        })
    }
}
module.exports = packageBL;