var hotdeals = function (destinationId, name, details, numberOfDays,chargesPerPerson,availability){
    this.destinationId = destinationId;
    this.name = name;
    this.details = details;
    this.numberOfDays = numberOfDays;
    this.chargesPerPerson = chargesPerPerson;
    this.discount = discount;
    this.timePeriod = timePeriod
    this.availability = availability;
}

hotdeals.toObject = function(result){
    return new hotdeals(result.destinationId, result.name, result.details, result.numberOfDays,result.chargesPerPerson,result.discount,result.timePeriod, result.availability);
}

module.exports = hotdeals;
