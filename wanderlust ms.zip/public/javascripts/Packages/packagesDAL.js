var connection = require('../Connections')
var PackagesDAL = {}



// this function should get all hotdeals from Hotdeal collection and returns the same   
PackagesDAL.getHotDeals = function(){
  return connection.getConnection().then(function(db) {
      var collection = db.collection('Hotdeals');
      return collection.find().toArray();
    }).then(function(Hotdeals) {
        return Hotdeals;
    })
};


// this function should get all destination from Destinations collection and returns the same 
PackagesDAL.getDestinations = function(continent){
    return connection.getConnection().then(function(db) {
        var collection = db.collection('Destinations');
        return collection.find({"continent": continent}).toArray();
      }).then(function(destinations) {
          return destinations;
      });
};

//this function returns all the destinations in the destinations collection
PackagesDAL.getDestinationstwo = function(){
    return connection.getConnection().then(function(db){
        var collection=db.collection('Destinations');
        return collection.find().toArray();
    }).then(function(destinations){
        return destinations;
    });
}



module.exports = PackagesDAL