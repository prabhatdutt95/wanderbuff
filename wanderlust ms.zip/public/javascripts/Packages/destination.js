var destination = function (destinationId, name, details, numberOfDays,chargesPerPerson,availability){
    this.destinationId = destinationId;
    this.name = name;
    this.details = details;
    this.numberOfDays = numberOfDays;
    this.chargesPerPerson = chargesPerPerson;
    this.availability = availability;
}

destination.toObject = function(result){
    return new destination(result.destinationId, result.name, result.details, result.numberOfDays,result.chargesPerPerson,result.availability);
}

module.exports = destination;

